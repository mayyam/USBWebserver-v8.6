/*jshint strict:false*/
casper.test.begin('true', 1, function(test) {
    test.assert(false);
    test.done();
});
