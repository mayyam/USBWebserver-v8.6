OpenLayers contributors:

* Antoine Abt
* Mike Adair
* Jeff Adams
* Seb Benthall
* Bruno Binet
* Stéphane Brunner
* Howard Butler
* Bertil Chaupis
* John Cole
* Tim Coulter
* Robert Coup
* Jeff Dege
* Roald de Wit
* Schuyler Erle
* Christian López Espínola
* John Frank
* Sean Gilles
* Pierre Giraud
* Ivan Grcic
* Andreas Hocevar
* Marc Jansen
* Ian Johnson
* Frédéric Junod
* Eric Lemoine
* Philip Lindsay
* Martijn van Oosterhout
* David Overstrom
* Tom Payne
* Corey Puffault
* Peter William Robins
* Gregers Rygg
* Tim Schaub
* Christopher Schmidt
* Tobias Schwinger
* Cameron Shorter
* Pedro Simonetti
* Paul Spencer
* Paul Smith
* Glen Stampoultzis
* James Stembridge
* Erik Uzureau
* Bart van den Eijnden
* Ivan Willig
* Thomas Wood
* Bill Woodall
* Steve Woodbridge
* David Zwarg

Some portions of OpenLayers are used under the Apache 2.0 license, available
in doc/licenses/APACHE-2.0.txt.

Some portions of OpenLayers are used under the MIT license, availabie in
doc/licenses/MIT-LICENSE.txt.

Some portions of OpenLayers are Copyright 2001 Robert Penner, and are used
under the BSD license, available in doc/licenses/BSD-LICENSE.txt
