/**
 * @type {Object}
 */
var exampleNS;



/**
 * @return {string} Renderer type.
 */
exampleNS.getRendererFromQueryString = function() {};


/**
 * @param {string} str String.
 * @return {string} Base64 string.
 */
exampleNS.strToBase64 = function(str) {};
